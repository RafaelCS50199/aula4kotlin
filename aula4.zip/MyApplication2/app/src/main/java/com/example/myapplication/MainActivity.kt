package com.example.myapplication


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val botaonext : Button = findViewById(R.id.button4)
        val botaoback : Button = findViewById(R.id.button3)

        botaonext.setOnClickListener{
            findNavController(R.id.fragmentContainerView3).navigate(R.id.action_fragGrenn_to_fragRed)

        }

        botaoback.setOnClickListener{
            findNavController(R.id.fragmentContainerView3).navigate(R.id.action_fragRed_to_fragGrenn)
        }
    }




}